define([mui], function(mui) {
    function init() {
        console.log(111)
            //初始化
        mui.init();
    }
});