require.config({
    baseUrl: 'js/',
    paths: {
		"mui":'dist/mui'
        "index": "pages/index"
    }
})